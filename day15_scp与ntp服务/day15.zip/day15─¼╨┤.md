# 10个命令

1.解压缩.tar.gz后缀

2.解压缩.tar后缀

3.解压缩.zip后缀

4.解压缩.gz后缀

5.同步系统时间、日期的命令，写2个

6.强制更新机器时间到阿里云时间服务器的命令

7.由于修改了ssh服务的端口号，需要重启ssh服务命令是。

8.禁止防火墙服务开机自启。

9.写出所有和linux用户有关的命令

10.写出所有和linux文件权限有关的命令。





# 10个单词

1. unit 单元
2. enable 启用
3. restart 重启
4. disable 禁用
5. reload 重新加载
6. firewall 防火墙
7. network 网络
8. active 激活
9. inactive 未激活
10. Console 控制台